import 'dotenv/config';

const OPT = { STRING: 3, INTEGER: 4, BOOLEAN: 5, USER: 6 };
const modes = [
  { name: "Basic", value: "basic" },
  { name: "Standard", value: "standard" },
  { name: "Advanced", value: "advanced" },
];

export const DISCORD_COMMANDS = [
  {
    name: "help",
    description: "List all LuaMore commands & usage guide",
  },
  {
    name: "setup",
    description: "Show setup instructions and embed interactive panel",
    options: [
      {
        type: OPT.STRING,
        name: "script_id",
        description: "Script public ID or UUID (optional)",
        required: false,
      },
    ],
  },
  {
    name: "panel",
    description: "Send an interactive panel to this channel",
    options: [
      {
        type: OPT.STRING,
        name: "panel_id",
        description: "Panel ID from your LuaMore dashboard",
        required: true,
      },
    ],
  },
  {
    name: "login",
    description: "Link your Discord to your LuaMore account via API key",
    options: [
      {
        type: OPT.STRING,
        name: "api_key",
        description: "Your LuaMore API key from Settings -> API Keys",
        required: true,
      },
    ],
  },
  {
    name: "create-script",
    description: "Create a new LuaMore script directly from Discord",
    options: [
      { type: OPT.STRING, name: "name", description: "Script name", required: true },
      { type: OPT.STRING, name: "code", description: "Lua source code", required: true },
      { type: OPT.BOOLEAN, name: "ffa", description: "Free for all / keyless access", required: false },
      { type: OPT.BOOLEAN, name: "obfuscate", description: "Obfuscate with LuaMore VM", required: false },
      { type: OPT.STRING, name: "mode", description: "Obfuscation level", required: false, choices: modes },
    ],
  },
  {
    name: "generatekey",
    description: "Generate a license key for a panel or script",
    options: [
      { type: OPT.STRING, name: "panel_id", description: "Panel ID or Script ID", required: true },
      { type: OPT.INTEGER, name: "hours", description: "Hours valid (0 = lifetime)", required: false, min_value: 0 },
      { type: OPT.STRING, name: "note", description: "Optional note or customer name", required: false },
      { type: OPT.USER, name: "user", description: "Discord user to assign key to", required: false },
    ],
  },
  {
    name: "whitelist",
    description: "Grant a Discord user access to a script",
    options: [
      { type: OPT.STRING, name: "script_id", description: "Script ID or public ID", required: true },
      { type: OPT.USER, name: "user", description: "User to whitelist", required: true },
      { type: OPT.INTEGER, name: "duration", description: "Hours valid (0 = lifetime)", required: false, min_value: 0 },
    ],
  },
  {
    name: "blacklist",
    description: "Revoke a Discord user's access to a script",
    options: [
      { type: OPT.STRING, name: "script_id", description: "Script ID or public ID", required: true },
      { type: OPT.USER, name: "user", description: "User to blacklist", required: true },
    ],
  },
  {
    name: "deletekey",
    description: "Permanently delete a license key",
    options: [
      { type: OPT.STRING, name: "key", description: "License key to revoke", required: true },
    ],
  },
  {
    name: "resethwid",
    description: "Reset your own HWID for a script",
    options: [
      { type: OPT.STRING, name: "script_id", description: "Script ID or public ID", required: true },
    ],
  },
  {
    name: "forceresethwid",
    description: "Force-reset a user's HWID (Script owner only)",
    options: [
      { type: OPT.STRING, name: "script_id", description: "Script ID or public ID", required: true },
      { type: OPT.USER, name: "user", description: "Discord user", required: true },
    ],
  },
  {
    name: "banhwid",
    description: "Ban a hardware ID from your scripts",
    options: [
      { type: OPT.STRING, name: "hwid", description: "Hardware ID string", required: true },
      { type: OPT.STRING, name: "reason", description: "Reason for ban", required: false },
    ],
  },
  {
    name: "unbanhwid",
    description: "Remove a hardware ID ban",
    options: [
      { type: OPT.STRING, name: "hwid", description: "Hardware ID to unban", required: true },
    ],
  },
  {
    name: "loader",
    description: "Get the executable loader snippet for a script",
    options: [
      { type: OPT.STRING, name: "script_id", description: "Script ID or public ID", required: true },
    ],
  },
  {
    name: "keys",
    description: "List your recent license keys",
    options: [
      { type: OPT.STRING, name: "panel_id", description: "Filter by panel ID", required: false },
    ],
  },
];

async function main() {
  const token = (process.env.DISCORD_BOT_TOKEN || "").trim();
  const clientId = (process.env.DISCORD_CLIENT_ID || "").trim();
  const guildId = (process.env.DISCORD_GUILD_ID || "").trim();

  if (!token || !clientId) {
    console.error("Error: DISCORD_BOT_TOKEN and DISCORD_CLIENT_ID are required in .env!");
    process.exit(1);
  }

  console.log(`[LuaMore Bot] Registering ${DISCORD_COMMANDS.length} slash commands...`);

  const url = guildId
    ? `https://discord.com/api/v10/applications/${clientId}/guilds/${guildId}/commands`
    : `https://discord.com/api/v10/applications/${clientId}/commands`;

  const res = await fetch(url, {
    method: "PUT",
    headers: {
      Authorization: `Bot ${token}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify(DISCORD_COMMANDS),
  });

  if (!res.ok) {
    const errorText = await res.text();
    throw new Error(`Discord API Error (${res.status}): ${errorText}`);
  }

  const data = await res.json();
  console.log(`[LuaMore Bot] Successfully registered ${data.length} commands with Discord!`);
}

main().catch((err) => {
  console.error("[LuaMore Bot] Registration failed:", err);
  process.exit(1);
});
