# 🛡️ LuaMore Discord Bot

Official standalone Discord bot for **LuaMore** — Roblox Script Obfuscation, Key System & Script Hosting.

---

## 🚀 Quick Setup & Installation

### 1. Prerequisites
- **Node.js 18+** or **Node.js 20+**
- A Discord Application & Bot created in the [Discord Developer Portal](https://discord.com/developers/applications)

### 2. Configure Environment Variables
Copy `.env.example` to `.env` and fill in your details:
```bash
cp .env.example .env
```

```env
DISCORD_BOT_TOKEN=your_bot_token_here
DISCORD_CLIENT_ID=your_application_client_id
DISCORD_PUBLIC_KEY=your_public_key_here
DISCORD_GUILD_ID=your_optional_guild_id_for_instant_slash_commands

LUAMORE_API_URL=https://luamore.app
LUAMORE_API_KEY=your_luamore_api_key
```

### 3. Install Dependencies
```bash
npm install
```

### 4. Register Slash Commands
```bash
npm run register
```

### 5. Start the Bot
```bash
npm start
```
For development with auto-reload:
```bash
npm run dev
```

---

## 📜 Included Features & Slash Commands

| Command | Description |
| :--- | :--- |
| `/help` | Detailed guide on commands & panels |
| `/setup` | Embed buyer control panel in the channel |
| `/panel <panel_id>` | Send interactive panel with Redeem/Script buttons |
| `/login <api_key>` | Link Discord profile with your LuaMore account |
| `/create-script` | Obfuscate and host a script from Discord |
| `/generatekey` | Generate a license key with custom expiration |
| `/whitelist` | Whitelist a user by Discord mention |
| `/blacklist` | Revoke a user's license or access |
| `/resethwid` | Reset hardware lock for a script |
| `/loader <id>` | Copy instant Roblox `loadstring(game:HttpGet(...))()` |

---

## 🌐 Webhook / HTTP Interactions (Alternative Mode)

If you prefer hosting serverless interactions without a persistent Gateway WebSocket:
1. Set the **Interactions Endpoint URL** in your Discord Developer Portal to:
   `https://<your-luamore-instance>/api/public/discord/interactions`
2. Configure `DISCORD_PUBLIC_KEY` in your environment.
