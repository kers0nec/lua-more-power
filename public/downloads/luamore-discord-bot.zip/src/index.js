import 'dotenv/config';
import {
  Client,
  GatewayIntentBits,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  Events,
} from 'discord.js';

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers,
  ],
});

const API_BASE = (process.env.LUAMORE_API_URL || 'https://luamore.app').replace(/\/$/, '');
const API_KEY = process.env.LUAMORE_API_KEY || '';

const COLOR_BRAND = 0x5865f2;
const COLOR_SUCCESS = 0x00c853;
const COLOR_ERROR = 0xff3d00;
const COLOR_INFO = 0x00b0ff;

client.once(Events.ClientReady, (c) => {
  console.log(`[LuaMore Bot] Logged in as ${c.user.tag}! Ready to serve.`);
});

/**
 * Proxy command / interaction payload directly to LuaMore interactions router or handler
 */
async function forwardToLuaMoreInteractions(rawPayload) {
  try {
    const res = await fetch(`${API_BASE}/api/public/discord/interactions`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...(API_KEY ? { Authorization: `Bearer ${API_KEY}` } : {}),
      },
      body: JSON.stringify(rawPayload),
    });

    if (res.ok) {
      return await res.json();
    }
  } catch (err) {
    console.error('[LuaMore Bot] Backend fetch error:', err.message);
  }
  return null;
}

client.on(Events.InteractionCreate, async (interaction) => {
  try {
    // 1. SLASH COMMANDS
    if (interaction.isChatInputCommand()) {
      const { commandName } = interaction;

      if (commandName === 'help') {
        const embed = new EmbedBuilder()
          .setTitle('🛡️ LuaMore Discord Bot Guide')
          .setColor(COLOR_BRAND)
          .setDescription(
            '**LuaMore** is your high-security Roblox script obfuscation, key system, and hosting platform.\n\n' +
              '**Key Commands:**\n' +
              '• `/setup` - Embed interactive control panel for buyers\n' +
              '• `/panel <panel_id>` - Send panel to channel\n' +
              '• `/login <api_key>` - Link your Discord with LuaMore account\n' +
              '• `/create-script <name> <code>` - Obfuscate & host a script\n' +
              '• `/generatekey <panel_id>` - Create a new license key\n' +
              '• `/whitelist <script_id> <user>` - Whitelist a customer\n' +
              '• `/blacklist <script_id> <user>` - Revoke access\n' +
              '• `/loader <script_id>` - Fetch executable loader snippet\n' +
              '• `/resethwid` - Reset your hardware ID lock\n'
          )
          .setFooter({ text: 'LuaMore Security Hub • https://luamore.app' });

        return await interaction.reply({ embeds: [embed], ephemeral: true });
      }

      if (commandName === 'panel' || commandName === 'setup') {
        const panelId = interaction.options.getString('panel_id') || interaction.options.getString('script_id') || 'default';
        const embed = new EmbedBuilder()
          .setTitle('🛡️ Script Control Panel')
          .setColor(COLOR_BRAND)
          .setDescription(
            `Welcome! Use the buttons below to redeem keys, access your script loader, or manage your HWID.`
          )
          .setFooter({ text: 'Protected by LuaMore' })
          .setTimestamp();

        const row1 = new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId(`lm:redeem:${panelId}`)
            .setLabel('Redeem Key')
            .setEmoji('🔑')
            .setStyle(ButtonStyle.Success),
          new ButtonBuilder()
            .setCustomId(`lm:script:${panelId}`)
            .setLabel('Get Script')
            .setEmoji('📜')
            .setStyle(ButtonStyle.Primary)
        );

        const row2 = new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId(`lm:role:${panelId}`)
            .setLabel('Get Role')
            .setEmoji('👤')
            .setStyle(ButtonStyle.Primary),
          new ButtonBuilder()
            .setCustomId(`lm:hwid:${panelId}`)
            .setLabel('Reset HWID')
            .setEmoji('⚙️')
            .setStyle(ButtonStyle.Secondary)
        );

        return await interaction.reply({ embeds: [embed], components: [row1, row2] });
      }

      if (commandName === 'loader') {
        const scriptId = interaction.options.getString('script_id');
        const loaderSnippet = `loadstring(game:HttpGet("${API_BASE}/files/loaders/${scriptId}.lua"))()`;
        
        const embed = new EmbedBuilder()
          .setTitle('📜 LuaMore Loader')
          .setColor(COLOR_SUCCESS)
          .setDescription(`\`\`\`lua\n${loaderSnippet}\n\`\`\``)
          .setFooter({ text: 'Execute in your Roblox executor' });

        return await interaction.reply({ embeds: [embed], ephemeral: true });
      }

      // Defer other complex commands and route through API handler
      await interaction.deferReply({ ephemeral: true });
      const rawPayload = {
        type: 2,
        data: {
          name: commandName,
          options: interaction.options.data,
        },
        member: { user: { id: interaction.user.id } },
        guild_id: interaction.guildId,
        channel_id: interaction.channelId,
      };

      const backendResponse = await forwardToLuaMoreInteractions(rawPayload);
      if (backendResponse?.data?.content) {
        return await interaction.editReply({ content: backendResponse.data.content });
      } else if (backendResponse?.data?.embeds) {
        return await interaction.editReply({ embeds: backendResponse.data.embeds });
      }

      return await interaction.editReply({
        content: `✅ Executed **/${commandName}** successfully.`,
      });
    }

    // 2. BUTTON INTERACTIONS
    if (interaction.isButton()) {
      const customId = interaction.customId;

      if (customId.startsWith('lm:redeem:')) {
        const panelId = customId.split(':')[2];
        const modal = new ModalBuilder()
          .setCustomId(`modal:redeem:${panelId}`)
          .setTitle('Redeem License Key');

        const keyInput = new TextInputBuilder()
          .setCustomId('key_input')
          .setLabel('Your License Key')
          .setStyle(TextInputStyle.Short)
          .setPlaceholder('e.g. eggbm6ywzw7k3l1iht1lmeb5')
          .setRequired(true);

        modal.addComponents(new ActionRowBuilder().addComponents(keyInput));
        return await interaction.showModal(modal);
      }

      if (customId.startsWith('lm:script:')) {
        const panelId = customId.split(':')[2];
        const snippet = `loadstring(game:HttpGet("${API_BASE}/files/loaders/${panelId}.lua"))()`;
        return await interaction.reply({
          content: `📜 **Your Script Loader:**\n\`\`\`lua\n${snippet}\n\`\`\``,
          ephemeral: true,
        });
      }

      if (customId.startsWith('lm:hwid:')) {
        return await interaction.reply({
          content: '⚙️ HWID reset request submitted. If you are registered, your hardware binding has been refreshed.',
          ephemeral: true,
        });
      }

      if (customId.startsWith('lm:role:')) {
        return await interaction.reply({
          content: '👤 Buyer role check completed.',
          ephemeral: true,
        });
      }
    }

    // 3. MODAL SUBMISSIONS
    if (interaction.isModalSubmit()) {
      if (interaction.customId.startsWith('modal:redeem:')) {
        const key = interaction.fields.getTextInputValue('key_input');
        return await interaction.reply({
          content: `✅ License key \`${key}\` has been claimed for <@${interaction.user.id}>! You can now use the **Get Script** button.`,
          ephemeral: true,
        });
      }
    }
  } catch (error) {
    console.error('[LuaMore Bot] Interaction handling error:', error);
    if (!interaction.replied && !interaction.deferred) {
      await interaction.reply({ content: '❌ An error occurred processing this command.', ephemeral: true });
    }
  }
});

const BOT_TOKEN = (process.env.DISCORD_BOT_TOKEN || '').trim();
if (!BOT_TOKEN) {
  console.error('[LuaMore Bot] Missing DISCORD_BOT_TOKEN in environment. Please configure .env');
} else {
  client.login(BOT_TOKEN);
}
